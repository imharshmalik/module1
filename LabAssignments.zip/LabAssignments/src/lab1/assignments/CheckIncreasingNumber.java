package lab1.assignments;

import java.util.Scanner;

public class CheckIncreasingNumber {
	public boolean checkNumber(int Number)
	{												// check the number is increasing number or not				
		int Flag=0;
		String string = String.valueOf(Number);
		int  len=string.length();
		for(int i=0 ; i<len-1 ;i++)
		{
			if(string.charAt(i)>string.charAt(i+1))
				Flag++;
		}
		if(Flag==0)
			return true;
		else
			return false;
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of n");
		int number=sc.nextInt();
		CheckIncreasingNumber obj = new CheckIncreasingNumber();
		boolean result = obj.checkNumber(number);
		if(result==true)
			System.out.println(number+" is an inceasing number");
		else
			System.out.println(number+" is not an increasing number");
		sc.close();
	}
}

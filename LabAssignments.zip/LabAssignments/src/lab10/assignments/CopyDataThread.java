package lab10.assignments;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread {

	FileInputStream File1;
	FileOutputStream File2;
	public void init(String Str1,String Str2)throws FileNotFoundException{
		try{
			File1=new FileInputStream(Str1);
			File2=new FileOutputStream(Str2);
		}catch(FileNotFoundException fe){
			System.out.println("Exception :"+fe); 
			throw fe;
		}
	}
	
	
public void copyContents()throws IOException, InterruptedException{
	try{
		int i=File1.read();
		int chacount=0;
		
		while(i!=-1){
			char ch1=(char)i;
			System.out.println(ch1);
			chacount++;
			if(chacount==10)
			{
				System.out.println("\n10 Characters Copied.");
				chacount=0;
				Thread.sleep(5000);
			}
			File2.write(i);
			i=File1.read();
			
		}}catch(IOException ioe)
		{
			System.out.println("Exception :"+ioe);
			throw ioe;
			
		}finally{
			if(File1!=null)
			{
				File1.close();
			}
			if(File2!=null)
			{
				File2.close();
			}
		}

	
}
public static void main(String[] args) throws InterruptedException{
	CopyDataThread  copy=new CopyDataThread();
	try{
		copy.init("C:\\Users\\shakchau\\Desktop\\Abc.txt","C:\\Users\\shakchau\\Desktop\\bcd.txt");
		copy.copyContents();
	}
	catch(IOException e){
		System.out.println("caught in main"+e);
		
	}
}

}

package lab13.assignments;

import java.util.Scanner;
import java.util.function.BiFunction;

public class Authenticate {

	public static void main(String[] args) 
		// TODO Auto-generated method stub
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the username: ");
		String uname=sc.next();
		System.out.println("Enter the password: ");
		String pass=sc.next();
		BiFunction<String, String, Boolean>check=(user,key)->user.equals("Shakti")&& key.equals("Spartan");
		boolean res=check.apply(uname,pass);
		if(res)
			System.out.println("Welcome "+uname);
		else
			System.out.println("Incorrect credentials");		
	}

}

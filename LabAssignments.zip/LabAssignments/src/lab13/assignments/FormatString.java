package lab13.assignments;
import java.util.Scanner;
import java.util.function.UnaryOperator;
@FunctionalInterface
interface AddSpace
{
	public void add(String str);
}

public class FormatString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UnaryOperator<String> a=(str)->{
			String result ="";
			for(int i=0;i<str.length();i++)
			{
				
					result=result+(str.charAt(i));
					if(i==str.length()-1)
						break;
					result=result +' ';
						}
				return result;
						};
						Scanner sc=new Scanner(System.in);
						System.out.println("Enter the String you wish to enter: ");
						String str=sc.nextLine();
						String s=a.apply(str);
						System.out.println(s);
			}
		}
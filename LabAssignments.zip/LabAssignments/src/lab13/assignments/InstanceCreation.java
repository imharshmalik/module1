package lab13.assignments;
import java.util.Scanner;
interface Instance
{
	public void bigger(int a,int b);
}
public class InstanceCreation {
	private int num1;
	private int num2;
	
	public int getNum1() {
		return num1;
	}
	public void setNum1(int num1)
	{
		this.num1=num1;
	}
	public int getNum2()
	{
		return num2;
	}
	public void setNum2(int num2)
	{
		this.num2=num2;
	}
	public void InstanceCreate(int num1, int num2)
	{
		if(num1>num2)
			System.out.println("First number is greater");
		else
			System.out.println("Second number is greater");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please Enter the Numbers");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		int a=sc.nextInt();
		System.out.println("Enter second number");
		int b=sc.nextInt();
		InstanceCreation br=new InstanceCreation();
		Instance x=br::InstanceCreate;
		x.bigger(a, b);
	}

}

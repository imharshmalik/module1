package lab14.cg.eis.bean;

import java.util.*;


import com.cg.eis.bean.Employee;

public class EmployeeDao {
List<Employee> elist=new ArrayList<Employee>();
public boolean addEmployee(Employee e) {
	boolean b=elist.add(e);
	return b;
}
/*public List<Employee> getEmployees(){
	return elist;
	
}*/
}


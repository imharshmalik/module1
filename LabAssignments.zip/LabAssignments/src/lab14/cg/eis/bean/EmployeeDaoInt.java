package lab14.cg.eis.bean;

import com.cg.eis.bean.Employee;

public interface EmployeeDaoInt {
public boolean addEmployee(Employee e);
}

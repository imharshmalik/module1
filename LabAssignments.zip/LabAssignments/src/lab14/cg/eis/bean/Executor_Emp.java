package lab14.cg.eis.bean;
import java.io.*;
import com.cg.eis.bean.Employee;
public class Executor_Emp {
public static void main(String[] args) throws IOException,NumberFormatException{
	EmployeeService es=new EmployeeService();
	BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
	int ch=0;
	do {
		System.out.println("Enter Employee Id:-");
		String seid=sc.readLine();
		int eid=Integer.parseInt(seid);
		System.out.println("Enter Employee Name:-");
		String ename=sc.readLine();
		System.out.println("Enter Employee Designation:-");
		String designation=sc.readLine();
		System.out.println("Enter Employee salary:-");
		double salary=Double.parseDouble(sc.readLine());
		System.out.println(eid);
		
		Employee e=new Employee(eid, ename, salary, designation);
		String scheme=es.retriveScheme(e.getSalary(), e.getDesignation());
		e.setScheme(scheme);
		System.out.println("scheme is"+e.getScheme());
		System.out.println(e.toString());
		//boolean add=es.addEmployee(e);
		System.out.println("Record added");
		
		System.out.println("select 0 to add more values or 1 to exit");
		ch=Integer.parseInt(sc.readLine());
	}
	while(ch!=1);
	
	
}
}

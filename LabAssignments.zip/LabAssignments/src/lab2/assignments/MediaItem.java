package lab2.assignments;

public class MediaItem extends Item{
	public MediaItem(){
		System.out.println("This is a Media Item");
	}
	private double runtime;
	public double getRuntime() {
		return runtime;
	}
	public void setRuntime(double d) {
		this.runtime = d;
	}
	

}

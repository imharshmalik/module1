package lab3.assignments;

import java.util.Arrays;
import java.util.Scanner;

public class CountTheCharactersInAnArray {

	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n = s.nextInt();
		char arr[] = new char[n];
		for(int i=0; i<n; i++)
			arr[i] = s.next().charAt(0);
		CountTheCharactersInAnArray obj = new CountTheCharactersInAnArray();
		obj.characterCount(arr);
		s.close();
	}
	
	void characterCount(char arr[]) {
		int len=arr.length;
		int flag=0;
		Arrays.sort(arr);
		for(int i=0; i<len; i+=flag) {
			if(i>=len)
				System.exit(0);
			flag=0;
			char ch=arr[i];
			for(int j=0; j<len; j++) {
					if(ch==arr[j])
						flag++;
			}
			System.out.println(arr[i]+" comes "+flag+" times.");
		} 
	}
}


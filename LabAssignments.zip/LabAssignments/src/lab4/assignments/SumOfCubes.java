package lab4.assignments;

import java.util.Scanner;

public class SumOfCubes {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the n digit number");
		int number = sc.nextInt();
		SumOfCubes obj = new SumOfCubes();
		obj.cubesOfDigits(number);
		sc.close();
	}
	
	// method to calculate the sum of the cubes of a digit
	public void cubesOfDigits(int number) {
		int temp,sum=0;
		while(number!=0) 
		{
			temp=number%10;
			sum=sum+(temp*temp*temp);
			number=number/10;
		}
		System.out.println("Sum of the cubes of the digits of a number is : "+sum);
	}
}


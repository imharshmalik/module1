package lab5.assignments;

import java.util.Scanner;

public class FibonacciSequence {
	public static void main(String args[]) {
		FibonacciSequence obj = new FibonacciSequence();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of to print  nth value of fibonacci series");
		int number = sc.nextInt();
		System.out.println("Press 1 For Recursive Method\nPress 2 For Non-Recursive Method");
		int choice =sc.nextInt();
		switch(choice) {
		case 1:
			int n=obj.recFib(number);
			System.out.println(number+" value of fibonacci series is : "+n);
			break;
		case 2:
			int n1=obj.nonRecFib(number);
			System.out.println(number+" value of fibonacci series is : "+n1);
			break;
		}
		sc.close();
	}
	
	// method to print the nth value using non recursive function
	public int nonRecFib(int number) {
		int n=0, a=1, b=1;
		for(int i=2 ; i<number ; i++) {
			n=a+b;
			a=b;
			b=n;
		}
		return n;
	}
	
	// method to print the nth value using recursive function
	public int recFib(int number) {
		if(number<=1)
			return number;
		else
			return (recFib(number-1)+recFib(number-2));
		
	}
}

package lab5.assignments;

import java.util.Scanner;

public class TrafficLights {
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select 1. For Red.");
		System.out.println("Select 2. For Yellow.");
		System.out.println("Select 3. For Green.");
		System.out.println("Select 4. For Exit.");
		System.out.println("Enter Your choice");
		int choice = sc.nextInt();
		// according to user's choice respective case will be execute
		while(true)
		{
		switch (choice) {
		case 1:
			System.out.println("Stop");
			break;
		case 2:
			System.out.println("Ready");
			break;
		case 3:
			System.out.println("Go");
			break;
		case 4:
			System.exit(0);
		default :
			System.out.println("Enter a valid choice.");
		}
		System.out.println("Enter Your choice");
		 choice = sc.nextInt();
	}
	
}
	
}

package lab5.assignments;

import java.util.Scanner;

public class ValidateAge {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the age of a person");
		int age = sc.nextInt();
		ValidateAge obj = new ValidateAge();
		obj.validateAge(age);
		sc.close();
	}
	
	// method to check age if less than or equal to 15 throw user defined exception
	public void validateAge(int age) {
		try
		{
			if(age<=15)
				throw new Exception("Age should be above 15");
			else
				System.out.println("Age is "+age);
		}
		catch(Exception e) {
			System.out.println("Error Occurred "+e.getMessage());
		}
	}
}

package lab5.assignments;

import java.util.Scanner;

public class ValidateEmployee {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String fName,lName;
		System.out.println("Enter First Name");
		fName=sc.nextLine();
		System.out.println("Enter Last Name");
		lName=sc.nextLine(); 
		ValidateEmployee obj = new ValidateEmployee();
		obj.checkNames(fName, lName);
		sc.close();
	}
	
	// method to check first and last name if blank throw user defined exception 
	public void checkNames(String firstName, String lastName) {
		try {
			if(firstName==null|| lastName==null) {
				throw new Exception("First and Last Name can not be blanked.");
			}
			else
				System.out.println("Name of an employee is "+firstName+" "+lastName);
		}
		catch(Exception e) {
			System.out.println("Error Occurred " +e.getMessage());
		}
	}
}

package com.bean;

 

import java.util.ArrayList;
import java.util.List;

 

public class Call {
    private int callId;
    private long calledNumber;
    private float duration;
    public int getCallId() {
        return callId;
    }
    
    public long getCalledNumber() {
        return calledNumber;
    }
    
    public float getDuration() {
        return duration;
    }

 

    public void setCallId(int callId) {
        this.callId = callId;
    }

 

    public void setCalledNumber(long calledNumber) {
        this.calledNumber = calledNumber;
    }

 

    public void setDuration(float duration) {
        this.duration = duration;
    }
    
    public Call()
    {
        
    }

 

    public Call(int callId, long calledNumber, float duration) {
        super();
        this.callId = callId;
        this.calledNumber = calledNumber;
        this.duration = duration;
    }

 

    public void parseData(String details)
    {
        String[] splittedArray = details.split(":");
    //    List<String> list = new ArrayList<String>();
        
        setCallId(Integer.parseInt(splittedArray[0]));
        setCalledNumber(Long.parseLong(splittedArray[1]));
        setDuration(Float.parseFloat(splittedArray[2]));
        
    }

 

}
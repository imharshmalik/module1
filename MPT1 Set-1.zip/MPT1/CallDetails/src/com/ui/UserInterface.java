package com.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.bean.Call;
import com.utility.CallHistory;

public class UserInterface {
	
	public static void main(String a[]){
		Scanner sc=new Scanner(System.in);
		Call callObj = new Call();
		CallHistory callHistoryObj = new  CallHistory ();
		List<String> list = new ArrayList<String>();
		System.out.println("Enter the number of call details");
		int noOfCalls = sc.nextInt();
		String allDetails;
		System.out.println("Enter the call details:");
		for (int i = 0; i < noOfCalls; i++) {
			allDetails = sc.next();
			callObj.parseData(allDetails);
			callHistoryObj.addCall(callObj);
		}
	
		System.out.println("Enter the called number");
		long calledNumberCheck = sc.nextLong();
		float calledDuration = callHistoryObj.findTotalDuration(calledNumberCheck);
		System.out.println(calledDuration);
	}

}

package com.ui;
import java.util.Scanner;
import com.bean.Call;
import com.utility.CallHistory;

public class UserInterface {
    
    public static void main(String a[]){
        Scanner sc=new Scanner(System.in);
        Call callObject = new Call();
        System.out.println("Enter the number of call details");
        int numberOfCallDetails = sc.nextInt();
        String[] callDetailsArray = new String[numberOfCallDetails+1];
        System.out.println("Enter the call details:");
        for(int i=1;i<=numberOfCallDetails;i++)
        {
            callDetailsArray[i] = sc.next();
            callObject.parseData(callDetailsArray[i]);
        }
        
        int callId = callObject.getCallId();
        long calledNumber = callObject.getCalledNumber();
        float callDuration = callObject.getDuration();
        
        Call callObject2 = new Call(callId,calledNumber,callDuration);
        CallHistory callHistoryObject = new CallHistory();
        callHistoryObject.addCall(callObject2);
        
        System.out.println("Enter the called number");
        long calledNumber2 = sc.nextLong();
        float totalDuration = callHistoryObject.findTotalDuration(calledNumber2);
        System.out.println("Total Duration :"+totalDuration);
    }
}
 
package com.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import com.utility.Shop;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		//Fill the UI code
		System.out.println("Enter the no of Face Creams you want to store:");
		int numberOfFaceCreams = sc.nextInt();
		int keyOfMap;
		String valueOfMap;
		Shop shopObj = new Shop();
		for(int i=0;i<numberOfFaceCreams;i++){
			System.out.println("Enter the key"+(i+1));
			keyOfMap = sc.nextInt();
			System.out.println("Enter the value"+(i+1));
			valueOfMap = sc.next();
			shopObj.addProductDetails(keyOfMap, valueOfMap);
		}	
		
	   Set s=shopObj.getProductMap().entrySet();
	    Iterator it=s.iterator();
	    while(it.hasNext()){
	    	Map.Entry me=(Map.Entry)it.next();
	    	System.out.println(me.getKey()+" "
	    	+me.getValue());
	    }
	    
	   System.out.println("Enter the product type to be searched");
	   String searchType = sc.next();
	   System.out.println(shopObj.searchBasedOnproduct(searchType));
	    
	}
}

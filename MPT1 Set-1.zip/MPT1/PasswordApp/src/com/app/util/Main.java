package com.app.util;

import java.util.Scanner;
import java.io.*;
public class Main
{

        public static void main(String args[])
        {
        	Scanner scanner = new Scanner(System.in);
            String str = scanner.nextLine();
            System.out.println(generate(str).toUpperCase());
        }


        public static String generate(String s) 
        {	
        	String password = "";
        	if(s.length()>=5) {
        		for(int i=0; i<s.length(); i=i+2) {
        			password = password+s.charAt(i);
        		}
        	return password;
        	}
        	else
        		 return ("Invalid Input");
          
        }
}

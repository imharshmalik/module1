//make the necessary change to make this class a Exception
public class SalaryNegativeException extends Exception{
	SalaryNegativeException(){	
		System.out.println("Invalid Salary");
	}
	SalaryNegativeException(String a){
		System.out.println("Invalid Salary");
	}
}

package dao;
import java.util.HashMap;
import bean.BankBean;

public class BankDAO {
		
		HashMap<Long, BankBean> hm = new HashMap<Long, BankBean>();
		
		public void addCustomer(BankBean beanObj1) {			
			hm.put(beanObj1.getAccNo(), beanObj1);			
		}
		
		public HashMap<Long,BankBean> hm(){					
			return hm;
		}
		
		public void deposit(BankBean beanObj3) 
		{
			float deposit = hm().get(beanObj3.getAccNo()).getBalance() + beanObj3.getDepAmount();					
			hm().get(beanObj3.getAccNo()).setBalance(deposit);		
		}
		
		public void withDraw(BankBean beanObj4) 	
		{
			float withdraw =hm().get(beanObj4.getAccNo()).getBalance() - beanObj4.getWithdrawAmount();		
			hm().get(beanObj4.getAccNo()).setBalance(withdraw);
		}
		
		public void transfer(BankBean  beanObj5)	
		{
			float updatedSourceBalance = hm().get(beanObj5.getSourceAccount()).getBalance() - beanObj5.getTransferAmount();
			hm().get(beanObj5.getSourceAccount()).setBalance(updatedSourceBalance);		
			float updatedDestinationBalance = hm().get(beanObj5.getDestinationAccount()).getBalance() + beanObj5.getTransferAmount();
			hm().get(beanObj5.getDestinationAccount()).setBalance(updatedDestinationBalance);		
		}
}
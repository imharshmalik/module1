package service;

import bean.BankBean;
import dao.BankDAO;
import dao.UserException;
public class BankService {

	BankDAO daoObj = new BankDAO();

	public void bankAccountCreate(BankBean beanObj1){
		daoObj.addCustomer(beanObj1);
	}

	public float showBalanceService(BankBean beanObj2) throws UserException{
		float bal=0;
		if(daoObj.hm().isEmpty()) 
		{								
			throw new UserException("Create an account first");		//Empty HashMap Exception
		}
		else 
		{
			if(daoObj.hm().containsKey(beanObj2.getAccNo())) 
			{
				bal=daoObj.hm().get(beanObj2.getAccNo()).getBalance();		//Getting the account balance
			}
			else
			{
				throw new UserException("Account doesn't exist");			//No such account exception
			}		
		}
		return bal;
	}

	public float depositService(BankBean beanObj3) throws UserException{
		float bal;
		if(daoObj.hm().isEmpty()) 
		{
			throw new UserException("Create an account first");
		}
		else 
		{
			if(daoObj.hm().containsKey(beanObj3.getAccNo())) 
			{
					daoObj.deposit(beanObj3);
					bal=daoObj.hm().get(beanObj3.getAccNo()).getBalance();	
			}
			else 
			{
				throw new UserException("Account number doesn't exist");
			}
		}
		return bal;
	}

	public float withdrawService(BankBean beanObj4) throws UserException{
		float bal=0;
		if(daoObj.hm().isEmpty()) 
		{
			throw new UserException("Please create an account first");
		}
		else 
		{		
			if(!daoObj.hm().containsKey(beanObj4.getAccNo())) 
				{		
					throw new UserException("Account number doesn't exist");
					
				}
				else 
				{
					if(beanObj4.getWithdrawAmount() < daoObj.hm().get(beanObj4.getAccNo()).getBalance())
						{
							daoObj.withDraw(beanObj4);	
							bal=daoObj.hm().get(beanObj4.getAccNo()).getBalance();	
						}
					else 
						{
	
							throw new UserException("Invalid withdrawal due to low balance");
						}
				}
		}
		return bal;
	}

	public String transferService(BankBean beanObj5) throws UserException{
		String s=null;
		if(daoObj.hm().isEmpty()) 
		{
			throw new UserException("Please create an account first.");
		}
		else 
		{
			if(daoObj.hm().containsKey(beanObj5.getSourceAccount())) 
			{					// CHECKING IF SOURCE ACCOUNT EXIST
				if(daoObj.hm().containsKey(beanObj5.getDestinationAccount()))
				{
					if(beanObj5.getSourceAccount()!=beanObj5.getDestinationAccount())
					{
					    // CHECKING IF DESTINATION ACCOUNT EXIST
						if(daoObj.hm().get(beanObj5.getSourceAccount()).getBalance() > beanObj5.getTransferAmount()) 
							{
								daoObj.transfer(beanObj5);
								s="Remaining balance in account number "+beanObj5.getSourceAccount()+" is: " 
									+daoObj.hm().get(beanObj5.getSourceAccount()).getBalance() 
									+ " Updated balance in account number "+beanObj5.getDestinationAccount()
									+" is: "+daoObj.hm().get(beanObj5.getDestinationAccount()).getBalance();
							}
						else 
							{
								throw new UserException("Invalid transfer due to low balance in source account");
							}
					}
					else
						{
							throw new UserException("Invalid transfer. Can't transfer to same account");
						}
				}
				else
					{
						throw new UserException("Destination account doesn't exist");
					}
			}
			else 
				{
					throw new UserException("Source account doesn't exist");
				}
		}
		return s;
	}
}

package service;

import bean.BankBean;
import dao.UserException;
public interface BankServiceInterface {
	public void bankAccountCreate(BankBean beanObj1) throws UserException;
	public float showBalanceService(BankBean beanObj2) throws UserException;
	public float depositService(BankBean beanObj3) throws UserException;
	public float withdrawService(BankBean beanObj4) throws UserException;
	public String transferService(BankBean beanObj5) throws UserException;	
}

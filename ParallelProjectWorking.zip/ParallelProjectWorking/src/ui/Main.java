package ui;
import java.util.Scanner;
import service.BankService;
import bean.BankBean;
import dao.UserException;

public class Main {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String args[]) throws UserException {
		int choice1;
		char choice2;
		do {
			System.out.println("Choose any one option:-\n "
					+ "Press 1 to create account \n "
					+ "Press 2 to display balance \n "
					+ "Press 3 to deposit money to account \n "
					+ "Press 4 to withdraw money from account \n "
					+ "Press 5 to transfer money from one account to another \n "
					+ "Press 6 to exit");
			choice1= sc.nextInt();
			
			switch(choice1) {
			case 1:
				try
				{
					createAccount();
				}
					catch(Exception e)
					{
						System.out.println("Invalid Input Try again!!!");
					}
				break;
				
			case 2:
				try
				{
					float bal=showBalance();
					System.out.println("Account balance is: " +bal);
				}
				catch(Exception e)
				{
					System.out.println("Try again");
				}	
				break;
				
			case 3:
				try
				{
					float bal=(float) deposit();
					System.out.println("The updated balance is: " + bal);
				}
				catch(Exception e)
				{
					System.out.println("Invalid input. Try again");
				}
				break;
				
			case 4:
				try
				{
					float bal=withdraw();
					System.out.println("Money withdrawn");
					System.out.println("The updated balance is: " +bal);
				}
				catch(Exception e)
				{
					System.out.println("Invalid Input Try again!!!");
				}
				break;
				
			case 5:
				String s;
				try
				{
					s=fundTransfer();
					if(s!=null)
					{
						System.out.println("Money transferred.");
						System.out.println(s);
					}
				}
				catch(Exception e)
				{
					System.out.println("Invalid input. Try again");
				}
				break;
				
			case 6:
				System.exit(0);
				
			default:
				System.out.println("Invalid Input");
			}
			
			System.out.println("Do you want to continue? (Y/N)");
			choice2 = sc.next().charAt(0);
		} 
		while(choice2 == 'y' || choice2 =='Y' );
	}
	
	
	static BankService serviceObj = new BankService();
	static long accNo = 30497;
		
	static void createAccount()  {
		try{
			System.out.print("Enter customer's name: ");
			String name = sc.next();
			System.out.print("Enter customer's phone number: ");
			long mobNo = sc.nextLong();
			System.out.print("Enter the initial balance: "); 
			float balance = (sc.nextFloat());
			BankBean beanObj1 = new BankBean(accNo, name, mobNo, balance);
			System.out.println("Account created successfully. New Account Number = " +accNo);
			serviceObj.bankAccountCreate(beanObj1);
			accNo++;
		}
		catch(Exception e)
		{
			throw (e);
		}
	}
	
	static float showBalance() throws UserException{
		
		System.out.print("Enter Account Number: ");
		long accNo = sc.nextLong();
		BankBean beanObj2 = new BankBean(accNo);
		float bal=serviceObj.showBalanceService(beanObj2);
		return bal;
	}
	
	static float deposit() throws UserException{
		
		float bal=0;
		try{
			System.out.print("Enter the account number: ");
			long accNo = sc.nextLong();
			System.out.print("Enter the amount to be deposited: ");
			float depAmount = sc.nextFloat();
			BankBean beanObj3 = new BankBean(accNo, depAmount);
			bal=serviceObj.depositService(beanObj3);
		}
		catch(Exception e)
		{
			throw (e);
		}
		return bal;
	}
	
	static float withdraw() throws UserException{
		
		float bal=0;
		try{
			System.out.print("Enter the account Number: ");
			long accNo = sc.nextLong();
			System.out.print("Enter the amount to be withdrawn: ");
			float withdrawAmount = sc.nextFloat();
			BankBean beanObj4 = new BankBean(withdrawAmount, accNo);
			bal=serviceObj.withdrawService(beanObj4);
		}
		catch(Exception e)
		{
			throw (e);
		}
		return bal;
	}
	
	static String fundTransfer() throws UserException{
		
		String s=null;
		try{
			System.out.println("Enter the source account number: ");
			long sourceAccNo = sc.nextLong();
			System.out.println("Enter the destination account number: ");
			long destAccNo = sc.nextLong();
			System.out.println("Enter the amount to be transferred: ");
			float transferAmount = sc.nextFloat();
			BankBean beanObj5 = new BankBean(sourceAccNo, destAccNo, transferAmount);
			s=serviceObj.transferService(beanObj5);
		}
		catch(Exception e)
		{
			throw (e);
		}
		return s;
	}
}